# ds_config.py
#
# DocuSign configuration settings

DS_CONFIG = {
    "ds_client_id": "9ebd81ff-ae14-4dfe-8a24-1a345528738a",  # The app's DocuSign integration key
    "ds_client_secret": "48ba7cf5-15f7-42ed-a294-7b0bad2788a9",  # The app's DocuSign integration key's secret
    "signer_email": "steve.wolfe@kcc.com",
    "signer_name": "Steve Wolfe",
    "app_url": "http://localhost:5000",  # The URL of the application. Eg http://localhost:5000
    # NOTE: You must add a Redirect URI of appUrl/ds/callback to your Integration Key.
    #       Example: http://localhost:5000/ds/callback
    "authorization_server_dev": "https://account-d.docusign.com",
    "click_api_client_host": "https://demo.docusign.net/clickapi",
    "rooms_api_client_host": "https://demo.rooms.docusign.com/restapi",
    "monitor_api_client_host": "https://lens-d.docusign.net",
    "allow_silent_authentication": True,  # a user can be silently authenticated if they have an
    # active login session on another tab of the same browser
    "target_account_id": None,  # Set if you want a specific DocuSign AccountId,
    # If None, the user's default account will be used.
    "demo_doc_path": "demo_documents",
    "doc_salary_docx": "World_Wide_Corp_salary.docx",
    "doc_docx": "World_Wide_Corp_Battle_Plan_Trafalgar.docx",
    "doc_pdf": "World_Wide_Corp_lorem.pdf",
    "doc_terms_pdf": "Term_Of_Service.pdf",
    "doc_txt": "Welcome.txt",
    # Payment gateway information is optional
    "gateway_account_id": "{DS_PAYMENT_GATEWAY_ID}",
    "gateway_name": "stripe",
    "gateway_display_name": "Stripe",
    "github_example_url": "https://github.com/docusign/code-examples-python/tree/master/app/eSignature/examples/",
    "monitor_github_url": "https://github.com/docusign/code-examples-python/tree/master/app/monitor/examples/",
    "documentation": "",  # Use an empty string to indicate no documentation path.
    "quickstart": "true",
}

DS_JWT = {
    "ds_client_id": "9ebd81ff-ae14-4dfe-8a24-1a345528738a",
    "ds_impersonated_user_id": "e9031fa4-2eff-4267-8ffb-f303d3432bd4",  # This is the ID of the KCNA Transportation / narate._trans@kcc.com
    "prod_account_id": "f072d9e2-a959-4945-a0da-7a1fb1abe9b5",
    "prod_user_id": "3e2ced29-db87-401b-9a34-a7482a1ccf82",
    "dev_private_key_file": r"C:\Users\U15405\Desktop\Code\Python\API\Addendums-python\app\dev-private.key",  # Create a new file in your repo source folder named private.key then copy and paste your RSA private key there and save it.
    "prod_private_key_file": r"C:\Users\U15405\Desktop\Code\Python\API\Addendums-python\app\prod-private.key",
    "dev_authorization_server": "account-d.docusign.com",
    "prod_authorization_server": "account.docusign.com",
}

EXAMPLES_API_TYPE = {
    "Rooms": False,
    "ESignature": True,
    "Click": False,
    "Monitor": False,
}
