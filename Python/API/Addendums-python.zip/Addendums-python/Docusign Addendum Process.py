import os
import pandas as pd
import time
from turbodbc import connect, make_options
from datetime import datetime
from shutil import copyfile
from win32com import client
import win32com.client as win32

# Main global variables used in the rest of the file
def globalVariables():
    # Get Username
    global userid
    userid = os.getlogin()

    # Set starting directory
    global pendingDir
    pendingDir = (
        "C:\\Users\\"
        + userid
        + "\\Kimberly-Clark\\Rates and Pricing - Agreements\\Addendums-Pending"
    )

    # Set finished directory
    global sentDir
    sentDir = (
        "C:\\Users\\"
        + userid
        + "\\Kimberly-Clark\\Rates and Pricing - Agreements\\Addendums-Sent"
    )


# Convert all of the Addendums-Pending .xlsx files to .pdf
def convertXLSXtoPDF():
    # Loop through all addendum files, and convert them to .pdf
    for filename in os.listdir(pendingDir):
        if filename.endswith(".xlsx"):
            filepath = pendingDir + "\\" + filename
            pdfpath = filepath.replace(".xlsx", ".pdf")
            if not os.path.isfile(pdfpath):

                # Open Microsoft Excel
                excel = client.Dispatch("Excel.Application")

                # Read Excel File
                sheets = excel.Workbooks.Open(filepath)
                work_sheets = sheets.Worksheets[0]

                # Convert into PDF File
                work_sheets.ExportAsFixedFormat(0, pdfpath)

                # Close workbook once complete
                sheets.Close(False)

    global fileCount
    fileCount = 0
    for filename in os.listdir(pendingDir):
        fileCount += 1


# Get Docusign Emails from Sharpeoint file
def sharepointEmails():
    sharepointFile = r"\\kimberlyclark.sharepoint.com\Teams\A286\Rates\ContractsPricing\Shared Documents\Docusign Emails.xlsx"
    xl = pd.ExcelFile(sharepointFile)
    global sharepointEmails
    df = xl.parse("Docusign Emails")
    sharepointEmails = df.fillna("")


# if there is no email for the carrier, send alert and skip
def missingEmail(carrier, filepath):
    outlook = win32.Dispatch("outlook.application")
    mail = outlook.CreateItem(0)
    mail.To = "Steve.Wolfe@kcc.com"
    mail.SendUsingAccount = "strategyandanalysis.ctt@kcc.com"
    mail.SentOnBehalfOfName = "strategyandanalysis.ctt@kcc.com"
    mail.Subject = "Rate Loading: Missing Carrier Email"
    # mail.Body="Message body"
    mail.HTMLBody = (
        """Hello, <br><br>
    No carrier email address was found for carrier """
        + carrier
        + """, and no Docusign envelope could be created.
    Please add this carrier asap to the <a href="https://kimberlyclark.sharepoint.com/Teams/A286/Rates/ContractsPricing/Shared%20Documents/Docusign%20Emails.xlsx">Docusign Emails File</a>. <br><br>
    The attached files have been removed from the <a href="https://kimberlyclark.sharepoint.com/Sites/A120/ratesandpricing/Document/Addendums-Pending/">Addendums-Pending Folder on Sharepoint</a>. <br><br>
    <b><span style="background-color: #FFFF00">This addendum will need to be manually processed through Docusign.</span></b><br><br>
    Thanks, <br><br>
    -Strategy & Analysis
    """
    )

    # To attach a file to the email (optional):
    pdfFile = filepath
    xlsxFile = filepath.replace(".pdf", ".xlsx")
    mail.Attachments.Add(pdfFile)
    mail.Attachments.Add(xlsxFile)

    mail.Send()

    # Attempt to delete the .pdf file
    try:
        os.remove(pdfFile)
    except OSError:
        pass

    # Attempt to delete the .xlsx file
    try:
        os.remove(xlsxFile)
    except OSError:
        pass


def killOutlook():
    # Close Outlook object
    WMI = win32.GetObject("winmgmts:")
    for p in WMI.ExecQuery('select * from Win32_Process where Name="Outlook.exe"'):
        # os.system("taskkill /pid /F /IM " + str(p.ProcessId))
        os.kill(p.ProcessId, 9)


# Process each .pdf file
def processAddendums():
    for filename in os.listdir(pendingDir):
        if filename.endswith(".pdf"):
            filepath = pendingDir + "\\" + filename
            # Get text character positions in file name for parsing
            markerA = filename.find("-")
            markerB = filename.find("(")
            markerC = filename.find(")")
            markerD = filename.rfind("-")

            # Parse strings from file name
            carrier = filename[0:markerA]
            scac = filename[markerA + 1 : markerB]
            addendumNumber = filename[markerB + 1 : markerC]
            addendumDate = filename[markerD + 2 : len(filename.replace(".pdf", ""))]

            # Carrier Contact Dataframe
            carrier_df = sharepointEmails.loc[sharepointEmails["Carrier"] == carrier]

            # If there's no matching carrier email, send notification to people, attach files, then delete from Addendums-Pending folder and go to next file
            if carrier_df.empty == True:
                missingEmail(carrier, filepath)
                continue

            docusignEmail = carrier_df["Signer Emails (To Addresses)"].values[0]
            ccAddresses = carrier_df["Notification Emails (CC Addresses)"].values[0]


# set global variables
globalVariables()

# Get emails from Sharepoint file
sharepointEmails()

# Convert all of the Addendums-Pending .xlsx files to .pdf
convertXLSXtoPDF()

# If there are no files to process, quit entire script
if fileCount == 0:
    quit()

# Process each .pdf file, and send through docusign then archive
processAddendums()
