"""
These are the user credentials used to
log into the Tableau Customer Portal
"""
CRED_UN = "steve.wolfe@kcc.com"
CRED_PW = "K1mberly!"
